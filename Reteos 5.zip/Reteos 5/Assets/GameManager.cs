using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//https://www.youtube.com/watch?v=JSns0pefXkg

public class GameManager : MonoBehaviour
{
 public GameObject[] Blocks;
    //This is for the transform degree
    public float movementFrequency = 0.8f;
 private float passedTime = 0;
    private GameObject currentBlock;
 void Start()
 {
    SpawnBlock();
 }

 void Update()
 {
    passedTime += Time.deltaTime;
    if(passedTime >= movementFrequency){
        passedTime -= movementFrequency;
        MoveBlock(Vector3.down);
    }
    UserInput();
 }
 void UserInput()
 {
     if (Input.GetKeyDown(KeyCode.LeftArrow))
     {
       MoveBlock(Vector3.left);
     }
     else if (Input.GetKeyDown(KeyCode.RightArrow))
     {
       MoveBlock(Vector3.right);
     }
    else if (Input.GetKeyDown(KeyCode.UpArrow))
        
    if (Input.GetKey(KeyCode.DownArrow))
    {
        movementFrequency = 0.2f;
    }
    else
     {
        movementFrequency = 0.8f;
     }            
 }



 void SpawnBlock()
 {
        int index = Random.Range(0, Blocks.Length); 
    currentBlock = Instantiate(Block[index], new Vector3(5, 18, 0), Quaternion.identity);
 }
 void MoveBlock(Vector3 direction)
    {
        currentBlock.transform.position += direction;
        if (!IsValidPosition())
        {
            currentBlock.transform.position -= direction;
            if (direction == Vector3.down)
            {
                GetComponent<GridScript>().UpdateGrid(currentBlock.transform);
                CheckForLines();
                SpawnBlock();
            }
        }
    }

    bool IsValidPosition()
    {
        return GetComponent<GridScript>().IsValidPosition(currentTetromino.transform);
    }

    void CheckForLines()
    {
    GetComponent<GridScript>().CheckForLines();
    }
}