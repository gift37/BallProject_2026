using UnityEngine;

public class FollowCoin : MonoBehaviour{

    public Transform Coin;
    void FixedUpdate()
    {
    Vector3 currentPosition = transform.position;
    currentPosition.x = Mathf.Lerp(currentPosition.x, followObject.position.x, .5f);
    currentPosition.z = -10;
    transform.position = currentPosition;
    }
}