using Unity.VisualScripting;
using UnityEngine;

public class Greenballscript : MonoBehaviour

{
    public float moveSpeed;
    private float jumpForce;
    public GameObject GreenBall;
    public Rigidbody2D My_rd;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        jumpForce = 10f;


    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.RightArrow))
        {
            Debug.Log("Right arrow key pressed");
            My_rd.AddForce(Vector2.right * moveSpeed, ForceMode2D.Impulse);
        }
        if (Input.GetKeyDown(KeyCode.LeftArrow))
        {
            Debug.Log("Left arrow key pressed");
            My_rd.AddForce(Vector2.left * moveSpeed, ForceMode2D.Impulse);
        }
        if (Input.GetKeyDown(KeyCode.UpArrow) || Input.GetKey(KeyCode.Space))
        {
            Debug.Log("uparrow key pressed");
            Jump();
        }
    }
    void Jump()
    {
        My_rd.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
    }
}
        
            
    



