using UnityEngine;
//https://www.youtube.com/watch?v=R9zimF2KIlM
public class PlayerMove : MonoBehaviour
{//This is just for the startscreen. Go to the sphere
    public Rigidbody rb;
    public float speed;

    public KeyCode rightMoveKey1;
    public KeyCode rightMoveKey2;
    public KeyCode leftMoveKey1;
    public KeyCode leftMoveKey2;
    public KeyCode forwardMoveKey1;
    public KeyCode forwardMoveKey2;
    public KeyCode backwardsMoveKey1;
    public KeyCode backwardsMoveKey2;


    void Start()
    {
        rb = gameobject
    }
}
