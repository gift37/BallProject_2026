using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    //This for the start screen
    public Transform target;
    public Vector3 offset;//This finds the x,y, and z
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        transform.position = target.position + offset;  
    }
}
