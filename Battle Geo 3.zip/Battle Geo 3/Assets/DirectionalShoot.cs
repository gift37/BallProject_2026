using UnityEngine;
//https://findmysourcecode.com/unity-2d-shoot-mouse-direction/
public class DirectionalShoot : MonoBehaviour
{
    public GameObject Bullet;
    public Transform firePoint; // This will follow the mouse
    public float bulletSpeed = 20f; 

    void Update()
    {
        AimGun();

        if (Input.GetButtonDown("Fire1"))
        {
            Shoot();
        }

    }

    void AimGun()
    {
        Vector3 mousePositon = Camera.main.Screen
    }
        
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    private Quaternion GetRotationFromAngle(float angle)
    {
        return Quaternion.AngleAxis(angle , Vector3.up);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
