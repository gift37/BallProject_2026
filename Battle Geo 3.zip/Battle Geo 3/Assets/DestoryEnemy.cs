using System.Collection;
using System.Collections.Generic;//helps keep one code method. So I don't have to make more
using UnityEngine;
https://pastecode.io/s/fq6tf4v3
public class DestoryEnemy : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    pubic GameObject objectToSpawn;
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if deltatime greater
    }
}
