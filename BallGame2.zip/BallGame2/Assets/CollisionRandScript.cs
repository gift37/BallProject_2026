using UnityEngine;

public class NewMonoBehaviourScript : MonoBehaviour
{
   public float forceMagnitude = 5f;
   public float changeDirectionInterval = 2f; 

   private Rigidbody rb;
   private float timer;
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        timer -= Time.deltaTime;
        if (timer <= 0f)
        {
            ApplyRandomForce();
            timer = changeDirectionInterval;
        }
    }
    void OnCollisionEnter2D(Collision2D other)
    {
        if (other.gameObject.tag == "Player")
        {
            Debug.Log("player collision detected");

        }     

         if ((other.gameObject.tag == "Walls") || (other.gameObject.tag == "Floors"))  
        {                                      
            Debug.Log("wall/floor collision detected");    
                                 
        }                             
    }
    void ApplyRandomForce()
    {
        Vector3 randomDirection = Random.insideUnitSphere.normalized;
        rb.AddForce(randomDirection * forceMagnitude, ForceMode.Impulse);
    }
}
