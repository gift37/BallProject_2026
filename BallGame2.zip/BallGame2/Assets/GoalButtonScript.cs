using UnityEngine;
using UnityEngine.SceneManagement; 

public class GoalButtonScript : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void OnCollisionEnter2D(Collision2D Goal)
    {
        if (Goal.gameObject.tag == "Player")
        {
            Debug.Log("collision detected");
            ChangeScene();
        }
    }

    // Update is called once per frame
    void ChangeScene()
    {
        SceneManager.LoadScene(1);
    }
}
