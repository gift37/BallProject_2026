using UnityEngine;

public class Camera_Follow_ball : MonoBehaviour{
    
    public Transform followObject;
    

    void FixedUpdate()
    {
    
      Vector3 currentPosition = transform.position;

      currentPosition.x = Mathf.Lerp(currentPosition.x, followObject.position.x, .5f);

      currentPosition.z = -10;
    
      transform.position = currentPosition;
    }  
}
  
