using UnityEngine;

public class TextOnOffScript : MonoBehaviour
{
    public GameObject onOffText;
    public bool showText;
    public bool textShowingNow;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        showText = true;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.L))
        {
            if (showText == true)
            {

                TurnOffText();

            }

        }
        else if (Input.GetKeyDown(KeyCode.K))
        {
            TurnOnText();
            showText = true;
        }
        if (showText == true)
        {
            onOffText.SetActive(true);
        }
        if (showText == false)
        {
            onOffText.SetActive(false);
        }
    }
   

   public void TurnOffText()                           
   {                                                   
   onOffText.SetActive(false);                    
   Debug.Log("turn Off text funct ran");           
   showText = false;                            
    }                                                   

    public void TurnOnText()                            
    {                                                   
        onOffText.SetActive(true);                      
        Debug.Log("turn on text funct ran");            
        showText = true;


    }
}
