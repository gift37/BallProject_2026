using UnityEngine;

public class RedballScript : MonoBehaviour
{
    public float moveSpeed;
    private float jumpForce;
    public GameObject RedBall;
    public Rigidbody2D My_rd;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        jumpForce = 5f;
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.A))
        {
            Debug.Log("A key pressed");
            My_rd.AddForce(Vector2.right * moveSpeed, ForceMode2D.Impulse);
        }
        if (Input.GetKeyDown(KeyCode.D))
        {
            Debug.Log("D key pressed");
            My_rd.AddForce(Vector2.left * moveSpeed, ForceMode2D.Impulse);
        }
        if (Input.GetKeyDown(KeyCode.W))
        {
            Debug.Log("W key pressed");
            Jump();
        }
    }
    void Jump()
    {
        My_rd.AddForce(Vector2.up * jumpForce, ForceMode2D.Impulse);
    }
}