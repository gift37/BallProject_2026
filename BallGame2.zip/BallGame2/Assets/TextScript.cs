using UnityEngine;

public class TextScript : MonoBehaviour
{
    public GameObject helloText;
    private bool showText;

    void Start()  
    {
      showText=false;
    }

    // Update is called once per frame
    void once_per_frame ()
    {
        if (showText=false)
        {
            helloText.SetActive(false);
        }
        if (Input.GetKey(KeyCode.L))
        {
            showText=true;
            helloText.SetActive(true);
        }
    }
}
