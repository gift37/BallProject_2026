using UnityEditor;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneChangeScript : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Update()
    {
         
        if (Input.GetKey(KeyCode.R)) 
        {
            RestartGame(); 
        }
    
    }

    
    void RestartGame()
    {
        SceneManager.LoadScene(0);
    }
}
