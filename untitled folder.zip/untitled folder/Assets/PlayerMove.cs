using UnityEngine;
//https://www.youtube.com/watch?v=R9zimF2KIlM
public class PlayerMove : MonoBehaviour
{//This is for 
    public float Speed
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
