using UnityEngine;

public class DirectionalShoot : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    private Quaternion GetRotationFromAngle(float angle)
    {
        return Quaternion.AngleAxis(angle , Vector3.up);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
