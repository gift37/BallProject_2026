using UnityEngine;

public class Camera_Follow_ball : MonoBehaviour{
    
    public Transfrom followObject;
    public GameObject GreenBall;

    void FixedUpdate()
    {
    
      Vector3 currentPosition = transform.position;

      currentPosition.x = Mathf.Lerp(currentPosition.0x, followObject.position.0x, .5f);

      currentPosition.z = -10;
    
      transform.position = currentPosition;
    }  
}
  
