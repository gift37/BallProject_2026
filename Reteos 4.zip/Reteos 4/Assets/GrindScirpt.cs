using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GridScript : MonoBehaviour
{
    public Transform[,] grid;
    public int width, height;
    void Start()
    {
grid = new Transform[width, height];
    }

    void Update()
    {

    }
}


