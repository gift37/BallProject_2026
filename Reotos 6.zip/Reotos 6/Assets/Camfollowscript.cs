using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    public Transform followObject;
    public GameObject Coin;
    
    void FixedUpdate()
    {
     Vector3 currentPosition = transform.position;
     currentPosition.x = Mathf.Lerp(currentPosition.0x ,followObject.position.0x ,.5f);
     currentPosition.z = -10;
     transform.position = currentPosition;
    }
}
